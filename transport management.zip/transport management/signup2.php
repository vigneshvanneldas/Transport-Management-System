<?php

include 'dbconnect.php';

$cname = $_POST['cname'];
$uname = $_POST['uname'];
$mail = $_POST['email'];
$pass = $_POST['password'];
$cpass = $_POST['conpassword'];

$sql = "INSERT INTO signup (cname,uname,email,password,conpassword) VALUES ('$cname','$uname','$mail','$pass','$cpass')";
if(mysqli_query($conn,$sql))
{
	echo "added";
}
else
{
	echo "error" . mysqli_error($conn);
}

?>