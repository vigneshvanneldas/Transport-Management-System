<?php
include '../dbconnect.php';

$sql = mysqli_query($conn,"SELECT Memo_no FROM form1 ORDER BY id DESC LIMIT 1");
$res = mysqli_fetch_assoc($sql);

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <title>Form1</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
    <link href="form1.css" type="text/css" rel="stylesheet">
    <script src="https://code.jquery.com/jquery-3.3.1.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>
</head>
<body>
	<div class="container-fluid bg">
		<div class="row">
			<div class="col-lg-12">
				<h5><center>freight memo</center></h5>
	 			<h1><center>Truckky.com</center></h1>
			</div>
		</div>
		<div class="row">
			<form role="form" id="form-data" method="POST" action="form-data2.php">
				<div class="col-lg-2">
				</div>
				<div class="col-lg-4">
					<label>User</label>
					<div class="input-group">
						<span class="input-group-addon">
							<i class="glyphicon glyphicon-user"></i>
						</span>
						<input type="text" name="user" class="form-control">
					</div>

					<label>Memo no.</label>
					<div class="input-group">
						<span class="input-group-addon">
							<i class="glyphicon glyphicon-book"></i>
						</span>
						<input type="text" name="memo" class="form-control" value="<?php echo $res['Memo_no']+1 ?>" readonly>
					</div>

					<label>From</label>
					<div class="form-group input-group">
						<span class="input-group-addon">
							<i class="glyphicon glyphicon-globe"></i>
						</span>
						<input type="text" name="from" class="form-control" value="Mumbai" id="fromPlace" readonly="">
					</div>

					<label>Weight(Ton)</label>
					<div class="form-group input-group">
						<span class="input-group-addon">
							<i class="glyphicon glyphicon-scale"></i>
						</span>
						<input type="text" name="weight" class="form-control" id="wg">
					</div>

					<label>Lorry Type</label>
					<div class="form-group input-group">
						<span class="input-group-addon">
							<i class="glyphicon glyphicon-list-alt"></i>
						</span>
						<input type="text" class="form-control" name="lorryType" id="lorry-type" readonly="">
					</div>


					<!--<label>Rupess in Words</label>
					<div class="form-group input-group">
						<span class="input-group-addon">  
						</span>
						<input type="text" name="rupess" class="form-control">
					</div> -->


				</div>

				<div class="col-lg-1">
				</div>
				<div class="col-lg-4">
					<label>Date</label>
					<div class="input-group">
						<span class="input-group-addon">
							<i class="glyphicon glyphicon-calendar"></i>
						</span>
						<input type="date" name="date" class="form-control" max="2019-12-12">
					</div>

				<!--	<label>Challan No.</label>
					<div class="input-group">
						<span class="input-group-addon">
							<i class="glyphicon glyphicon-list-alt"></i>
						</span>
						<input type="text" name="challan" class="form-control">
					</div> -->

					<label>Mob no.</label>
					<div class="input-group">
						<span class="input-group-addon">
							<i class="glyphicon glyphicon-book"></i>
						</span>
						<input type="text" name="mob" class="form-control">
					</div>


					<!--<label>Distance(km)</label>
					<div class="form-group input-group">
						<span class="input-group-addon">
							<i class="glyphicon glyphicon-map"></i>
						</span>
						<input type="text" name="distance" class="form-control" id="dist" readonly="">
					</div> -->


					<label>To</label>
					<div class="form-group input-group">
						<span class="input-group-addon">
							<i class="glyphicon glyphicon-globe"></i>
						</span>
						<select id="toPlace" class="form-control" name="to">
							<option disabled="" selected="">--Select to--</option>
						</select>
					</div>

					<label>Distance(km)</label>
					<div class="form-group input-group">
						<span class="input-group-addon">
							<i class="glyphicon glyphicon-map"></i>
						</span>
						<input type="text" name="distance" class="form-control" id="dist" readonly="">
					</div>

					<!--<label>No. of Trucks Required</label>
					<div class="form-group input-group">
						<span class="input-group-addon">
							<i class="glyphicon glyphicon-inbox"></i>
						</span>
						<input type="text" name="packages" class="form-control" id="p">
					</div> -->

					<label>Rate</label>
					<div class="form-group input-group">
						<span class="input-group-addon"> ₹ 
							<!--rate_formula(20_ton*1500_km)   
							1500=distance 
							-->
						</span>
						<input type="text" name="rate" class="form-control" id="r" readonly>
					</div>

					<label>Advance</label>
					<div class="form-group input-group">
						<span class="input-group-addon"> ₹ 
							
						</span>
						<input type="text" name="Advance" class="form-control">
					</div>
				</div>
				<div class="col-lg-1">
					</div>
					<div class="col-lg-12">
				<button type="submit" class="btn btn-default" style="margin-left: 50%;">submit</button> 
				
				<!-- <button type="Print" class="btn btn-default" style="margin-left: 70%;" onClick="window.print()">Print</button> -->
				
			</div>

			</form>
		</div>
	</div>
	<script type="text/javascript" src="index.js"></script>
	<script>
		
	</script>
</body>
</html>