$(document).ready(function(){
	var data = {
			"Andhra Pradesh":1014,
			"Arunachal":3415,
			"Assam":2980,
			"Bihar":1833,
			"Chattisgarh":1143,
			"Gujarat":686,
			"Harayana":1476,
			"Himachal Pradesh":1771,
			"Jammu and Kashmir":1909,
			"Jharkhand":1753,
			"Karnataka":653,
			"Kerala":1297,
			"Madhya Pradesh":953,
			"Manipur":3322,
			"Meghalaya":2892,
			"Mizoram":3413,
			"Nagaland":3260,
			"Punjab":1717,
			"Rajasthan":1116,
			"Sikkim":2494,
			"Telangana":785,
			"Uttar Pradesh":1446,
			"Uttarakhand":1751,
			"West Bengal":2123,
			"Odisha":1563,
			"Tamil Nadu":1305,
			"Chandigarh":1143,
			"Dadra and Nagar Haveli":158,
			"Daman and Diu":176,
			"Delhi":1420,
			"Goa": 586,

		};

		Object.keys(data).forEach(function(key) {
    		$('#toPlace').append('<option value="'+key+'">'+key+'</option>');
		});

		$('#toPlace').change(function(){
			$('#dist').val(data[$('#toPlace').val()]);
		});
	/*$('#dist').focus(function(){
		var from = $('#fromPlace').val();
		var to = $('#toPlace').val();
		$('#dist').val(data[to]);
	});*/

	$('#lorry-type').focus(function(){
		var w = $('#wg').val();
		if(w > 0 && w <1) {
			$('#lorry-type').val('tempo');
		}
		else if(w > 1 && w < 10) {
			$('#lorry-type').val('truck');
		}
		else if(w >10) {
			$('#lorry-type').val('trailer');
		}
	});
		

	$('#r').focus(function(){
		var dist = $('#dist').val();
		var p = $('#p').val();
		var w = $('#wg').val();
		$('#r').val(w*dist+30);
	});
	
});