<?php

include '../dbconnect.php';

$data = $_POST;

$user = $data['user'];
$Memo_no = $data['memo'];
$mobno = $data['mob'];
$from = $data['from'];
$to = $data['to'];						
$wg = $data['weight'];						
$distance = $data['distance'];
$rate = $data['rate'];      
$lorry_type = $data['lorryType'];			
$advance = $data['Advance'];											

$res = mysqli_query($conn,"INSERT INTO form1 ( user,Memo_no,mobno, source, destn, weight,distance,lorrytype ,rate,advance) VALUES ('$user','$Memo_no','$mobno','$from','$to','$wg','$distance','$lorry_type','$rate','$advance')");
if( $res) {
	//echo 'submitted';
	include '../../../pdf/print_pdf.php';
}
else {
	print_r($data);
	echo "error:: " . mysqli_error($conn);
}
?>