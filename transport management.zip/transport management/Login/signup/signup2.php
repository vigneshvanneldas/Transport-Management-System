<?php

include 'dbconnect.php';
//error_reporting(0);
$cname = 'truckky';
$username=$_POST['username'];
$mail = $_POST['email'];
$pass = $_POST['password'];
$cpass = $_POST['pwd2'];

$sql = "INSERT INTO signup (username,email,password,conpassword) VALUES ('$username','$mail','$pass','$cpass')";
if(mysqli_query($conn,$sql))
{
	header("Location: ../login.php");

}
else
{
	echo "error::" . mysqli_error($conn);
	
}

?>
