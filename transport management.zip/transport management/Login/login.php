<!DOCTYPE html>
<html lang="en">
<head>
    <title>Login</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.4/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="../fontawesome/css/font-awesome.css">
    <link href="css/login.css" type="text/css" rel="stylesheet">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
    <script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.4/js/bootstrap.min.js"></script>
</head>
<body>
<div class="container-fluid bg">
	 <div class="row">
	 	<div class="col-md-4 col-sm-4 col-xs-12"></div>
	 	<div class="col-md-4 col-sm-4 col-xs-12">
	 		<form class="form-container" action="login2.php" method="POST">
	 			<h1>Login Here</h1>

	 			<div class="form-group ">
							<label for="email" class="cols-sm-2 control-label">Your Email</label>
							<div class="cols-sm-10">
								<div class="input-group">
								<span class="input-group-addon">
										<i class="glyphicon glyphicon-envelope"></i>
									</span>
									<input type="email" class="form-control" name="email" id="email"  placeholder="Enter your Email id" pattern="([A-Za-z0-9_\-\.])+\@([A-Za-z0-9_\-\.])+\.([A-Za-z]{2,4})" title="Must contain at least two number and one uppercase and lowercase letter, a @ symbol and at least 10 or more characters" required/>
								</div>
							</div>
				</div>
	 			<div class="form-group">
							<label for="password" class="cols-sm-2 control-label">Password</label>
							<div class="cols-sm-10">
								<div class="input-group">
									<span class="input-group-addon">
										<i class="glyphicon glyphicon-lock"></i>
									</span>
									<input type="password" class="form-control" name="password" id="password"  placeholder="Enter your Password" pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{10,}" name="pwd1" onchange="form.pwd2.pattern = RegExp.escape(this.value);" title="Must contain at least two number and one uppercase and lowercase letter, a Special Caharacter and at least 10 or more characters" required/>
								</div>
							</div>
				</div>
	 				<button type="submit" class="btn btn-success btn-block">SUBMIT</button><br>
				<div>
					<label for="submit-form" tabindex="0"></label>
     				 <span class="psw"><a href="../Login/signup/signup.php">SignUp </a></span>
  			        </div>						
	 		</form>
		</div>
<div class="col-md-4 col-sm-4 col-xs-12"></div>
</div>
</div>	 
</body>
</html>		
