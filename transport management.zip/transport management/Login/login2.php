<?php


	$conn = mysqli_connect("localhost","root","","truckky");
	$result = mysqli_query($conn,"SELECT * FROM signup WHERE email='" . $_POST["email"] . "' and password = '". $_POST["password"]."'");
	$count  = mysqli_num_rows($result);
	if($count==0) {
		echo '<script language="javascript">';
		echo 'alert("Invalid Username or Password!")';
		echo '</script>';
	} else {
		//$message("You are successfully authenticated!");
		echo '<script language="javascript">';
		echo 'alert("message successfully sent")';
		echo '</script>';
		header('Location:../Login/signup/signup_form/form1.php');
		exit;
	}

?>