<!DOCTYPE html>
<html lang="en">
<head>
    <title>Form1</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
    <link href="form1.css" type="text/css" rel="stylesheet">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>
</head>
<body>
	<div class="container-fluid bg">
		<div class="row">
			<div class="col-lg-12">
				<h5><center>freight memo</center></h5>
	 			<h1><center>Truckky.com</center></h1>
			</div>
		</div>
		<div class="row">
			<form role="form">
				<div class="col-lg-2">
				</div>
				<div class="col-lg-4">
					<label>User</label>
					<div class="input-group">
						<span class="input-group-addon">
							<i class="glyphicon glyphicon-user"></i>
						</span>
						<input type="text" name="user" class="form-control">
					</div>

					<label>Memo no.</label>
					<div class="input-group">
						<span class="input-group-addon">
							<i class="glyphicon glyphicon-book"></i>
						</span>
						<input type="text" name="memo" class="form-control">
					</div>

					<label>From</label>
					<div class="form-group input-group">
						<span class="input-group-addon">
							<i class="glyphicon glyphicon-globe"></i>
						</span>
						<input type="text" name="from" class="form-control">
					</div>

					<label>Lorry Type</label>
					<div class="form-group input-group">
						<span class="input-group-addon">
							<i class="glyphicon glyphicon-list-alt"></i>
						</span>
						<select class="form-control">
							<option disabled selected> -- select lorry type -- </option>
							<option>Truck</option>
							<option>Tempo</option>
							<option>Trailer</option>
						</select>
					</div>

					<label>Weight(kg)</label>
					<div class="form-group input-group">
						<span class="input-group-addon">
							<i class="glyphicon glyphicon-scale"></i>
						</span>
						<input type="text" name="weight" class="form-control" id="wg">
					</div>

					<label>Rupess in Words</label>
					<div class="form-group input-group">
						<span class="input-group-addon">  
						</span>
						<input type="text" name="rupess" class="form-control">
					</div>


				</div>

				<div class="col-lg-1">
				</div>
				<div class="col-lg-4">
					<label>Date</label>
					<div class="input-group">
						<span class="input-group-addon">
							<i class="glyphicon glyphicon-calendar"></i>
						</span>
						<input type="date" name="date" class="form-control" max="2019-12-12">
					</div>

					<label>Challan No.</label>
					<div class="input-group">
						<span class="input-group-addon">
							<i class="glyphicon glyphicon-list-alt"></i>
						</span>
						<input type="text" name="challan" class="form-control">
					</div>

					<label>To</label>
					<div class="form-group input-group">
						<span class="input-group-addon">
							<i class="glyphicon glyphicon-globe"></i>
						</span>
						<input type="text" name="to" class="form-control">
					</div>

					<label>No. of Packages</label>
					<div class="form-group input-group">
						<span class="input-group-addon">
							<i class="glyphicon glyphicon-inbox"></i>
						</span>
						<input type="text" name="packages" class="form-control" id="p">
					</div>

					<label>Rate</label>
					<div class="form-group input-group">
						<span class="input-group-addon"> ₹ 
							
						</span>
						<input type="text" name="rate" class="form-control" id="r" readonly>
					</div>

					<label>Advance</label>
					<div class="form-group input-group">
						<span class="input-group-addon"> ₹ 
							
						</span>
						<input type="text" name="Advance" class="form-control">
					</div>
				</div>
				<div class="col-lg-1">
					</div>
					<div class="col-lg-12">
				<button type="submit" class="btn btn-default" style="margin-left: 10%;">submit</button> 
				
				<button type="Print" class="btn btn-default" style="margin-left: 70%;" onClick="window.print()">Print</button>
				
			</div>

			</form>
		</div>
	</div>
	<script type="text/javascript" src="index.js"></script>
</body>
</html>