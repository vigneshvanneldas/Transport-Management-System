<?php

include 'dbconnect.php';
error_reporting(0);
$username=$_POST['username'];
$mail = $_POST['email'];
$pass = $_POST['password'];
$cpass = $_POST['conpassword'];

$sql = "INSERT INTO signup (username,email,password,conpassword) VALUES ('$username','$mail','$pass','$cpass')";
if(mysqli_query($conn,$sql))
{
	echo "added";
	if(isset($_POST['Submit'])) 
	{
	    // the form was submitted

	    // ...
	    // perform your logic

	    // redirect if login was successful
	    header('../signup/signup_form/form1.php');
	}

}
else
{
	echo "error" . mysqli_error($conn);
}

?>