<?php

include 'dbconnect.php';
error_reporting(0);
$user=$_POST['user'];
$ = $_POST['email'];
$pass = $_POST['password'];
$cpass = $_POST['pwd2'];

$sql = "INSERT INTO form1 (user,From,email,password,conpassword) VALUES ('$cname','$username','$mail','$pass','$cpass')";
if(mysqli_query($conn,$sql))
{
	echo "added";
	if(isset($_POST['Submit'])) 
	{
	    // the form was submitted

	    // ...
	    // perform your logic

	    // redirect if login was successful
	    header('location: ../../signup_form/form1.html');
	}

}
else
{
	echo "error" . mysqli_error($conn);
}

?>