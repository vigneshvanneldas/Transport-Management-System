<?php

//include '../Login/signup/dbconnect.php';
//$res = mysqli_query($conn,"SELECT * FROM form1 WHERE id=2");
//$vals = mysqli_fetch_assoc($res);

require_once('fpdi/src/autoload.php');
require_once('fpdf.php');

require_once('fpdi/src/Fpdi.php');
require_once('fpdi/src/FpdfTpl.php');

$pdf = new \setasign\Fpdi\Fpdi();
$pdf->AddPage();
$filename = "../../../pdf/invoice.pdf";   //pdf filename
$pdf->setSourceFile($filename); 

$tplIdx = $pdf->importPage(1); 
$pdf->useTemplate($tplIdx, null, null, 216,280);  // last 2 options are width and height of new pdf
$pdf->SetFont('Arial','',16);    // font settings
//$pdf->Cell(40,10,'Hello World!',0,0);   // display text
$pdf->setXY(53,135);               // change current cursor location
$pdf->Cell(25,10,$_POST['user'],0,0);

$pdf->setXY(53,145);               // change current cursor location
$pdf->Cell(25,10,$_POST['memo'],0,0);

$pdf->setXY(53,156);               // change current cursor location
$pdf->Cell(25,10,$_POST['mob'],0,0);

$pdf->setXY(53,167);               // change current cursor location
$pdf->Cell(25,10,$_POST['from'],0,0);

$pdf->setXY(53,178);               // change current cursor location
$pdf->Cell(25,10,$_POST['to'],0,0);

$pdf->setXY(57,189);																
$pdf->Cell(25,10,$_POST['distance'],0,0);

$pdf->setXY(57,210);
$pdf->Cell(25,10,$_POST['weight'],0,0);

$pdf->setXY(159,75);
$pdf->Cell(25,10,rand(1000,10000000),0,0);

$pdf->setXY(57,200);
$pdf->Cell(25,10,$_POST['lorryType'],0,0);  

$pdf->setXY(57,220);
$pdf->Cell(25,10,$_POST['Advance'],0,0);

$pdf->setXY(164,235);
$pdf->Cell(25,10,$_POST['rate'],0,0);


$pdf->Output();
//$pdf->Output('newfile.pdf','D');
?>