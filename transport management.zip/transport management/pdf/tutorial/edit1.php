<?php

require_once('../fpdi/src/autoload.php');
require_once('../fpdf.php');

require_once('../fpdi/src/Fpdi.php');
require_once('../fpdi/src/FpdfTpl.php');

$pdf = new \setasign\Fpdi\Fpdi();
$pdf->AddPage();
$filename = "truckky.pdf";   //pdf filename
$pdf->setSourceFile($filename); 

$tplIdx = $pdf->importPage(1); 
$pdf->useTemplate($tplIdx, null, null, 216,280);  // last 2 options are width and height of new pdf
$pdf->SetFont('Arial','',16);    // font settings
//$pdf->Cell(40,10,'Hello World!',0,0);   // display text
$pdf->setXY(53,135);               // change current cursor location
$pdf->Cell(25,10,'Hello World!',0,0);

$pdf->Output();
?>